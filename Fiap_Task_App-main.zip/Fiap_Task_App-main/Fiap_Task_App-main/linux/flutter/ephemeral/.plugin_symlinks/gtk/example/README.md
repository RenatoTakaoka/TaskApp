# Example

![screenshot](https://raw.githubusercontent.com/ubuntu-flutter-community/gtk_settings.dart/main/example/screenshot.png)
